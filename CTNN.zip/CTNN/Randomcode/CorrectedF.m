function F = CorrectedF(Y,u,e)

% The projection of a 3 way tensor onto the ball of spectral norm C={X:\|X\|<=a}
%
% min_X 0.5*||X-Y||_F^2 s.t. X\in C
%
% Y     -    n1*n2*n3 tensor
%
% X     -    n1*n2*n3 tensor
% trank -    tensor tubal rank of X
%
% version 2.0 - 09/09/2017
%
% Written by Canyi Lu (canyilu@gmail.com)
% 

[n1,n2,n3] = size(Y);
F = zeros(n1,n2,n3);
Y = fft(Y,[],3);
tnn = 0;
trank = 0;
% first frontal slice
[U,S,V] = svd(Y(:,:,1),'econ');
S = diag(S);
b = max(S);
c = S./b;
fai = @(c,u,e) sign(c).*(1+e^u).*(abs(c).^u)./(abs(c).^u+e^u);
fi = fai(c,u,e);
% for i=1:t
%     D(i,i)=fi(i);
% end

S = fi;

r = length(find(S~=0));
S = S(1:r);
F(:,:,1) = U(:,1:r)*diag(S)*V(:,1:r)';
tnn = tnn+sum(S);
trank = max(trank,r);

% i=2,...,halfn3
halfn3 = round(n3/2);
for i = 2 : halfn3
    [U,S,V] = svd(Y(:,:,i),'econ');
    S = diag(S);
    b = max(S);
    c = S./b;
    fai = @(c,u,e) sign(c).*(1+e^u).*(abs(c).^u)./(abs(c).^u+e^u);
    fi = fai(c,u,e);

    S = fi;
    r = length(find(S~=0));
    S = S(1:r);
    F(:,:,i) = U(:,1:r)*diag(S)*V(:,1:r)';    
    F(:,:,n3+2-i) = conj(F(:,:,i));
    tnn = tnn+sum(S)*2;
    trank = max(trank,r);
end

% if n3 is even
if mod(n3,2) == 0
    i = halfn3+1;
    [U,S,V] = svd(Y(:,:,i),'econ');
    S = diag(S);
    b = max(S);
    c = S./b;
    fai = @(c,u,e) sign(c).*(1+e^u).*(abs(c).^u)./(abs(c).^u+e^u);
    fi = fai(c,u,e);
    S = fi;     
    r = length(find(S~=0));
    S = S(1:r);
    F(:,:,i) = U(:,1:r)*diag(S)*V(:,1:r)';
    tnn = tnn+sum(S);
    trank = max(trank,r);
end
tnn = tnn/n3;
F = ifft(F,[],3);
