%% compute y=A*x

function y = AMVMx(A,x)
        % y = A*x
        y = x(A);
end