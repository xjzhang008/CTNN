%% compute   y = A'*b

function y = AtMVMx(A,b,dim)
        % y = A'*b
        y = zeros(prod(dim),1);
        y(A) = b;
        y = reshape(y,dim);
end