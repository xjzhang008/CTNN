%% P_Omega(X)

function P = POmega(X,A,dim)
        
        b = X(A);
        P = AtMVMx(A,b,dim);
end