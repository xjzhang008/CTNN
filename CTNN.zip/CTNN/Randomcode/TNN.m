function [X Z W trank] = TNN(F,y,Omega,dim,opts)


if ~exist('opts', 'var')
    opts = [];
end    
if isfield(opts, 'tol');         tol = opts.tol;              end
if isfield(opts, 'm');           m = opts.m;                  end
if isfield(opts, 'c');           c = opts.c;                  end
if isfield(opts, 'beta');        beta = opts.beta;            end
if isfield(opts, 'MaxIte');      MaxIte = opts.MaxIte;        end
if isfield(opts, 'X0');          X0 = opts.X0;                end
if isfield(opts, 'W0');          W0 = opts.W0;                end
if isfield(opts, 'Z0');          Z0 = opts.Z0;                end
if isfield(opts, 'mu');          mu = opts.mu;                end
if isfield(opts, 'Omega');       Omega = opts.Omega;          end
if isfield(opts, 'dim');         dim = opts.dim;              end
if isfield(opts, 'gamma');       gamma = opts.gamma;          end
if isfield(opts, 'xi');          xi  = opts.xi;               end
if isfield(opts, 'Theta');       Theta = opts.Theta;          end


for k = 1:MaxIte
    % updata u^{k+1/2}
    um = (y - AMVMx(Omega, X0 + beta*(mu*F + W0 - Z0)))/(m + beta);
    
    % updata W
    AZ = X0/beta + mu*F + AtMVMx(Omega,um,dim) - Z0 ;
    W = - AZ + (sign(AZ).*min(abs(beta*AZ),c))/beta;
    
     % updata u^{k+1}
    u = (y - AMVMx(Omega, X0 + beta*(mu*F + W - Z0)))/(m + beta);
    
    % updata Z
    AW = mu*F + AtMVMx(Omega,u,dim) + W + X0/beta;
    [Z,tnn,trank] = projection(AW,mu);
    
    % updata the multiplier X
    X = X0 - gamma*beta*(Z - mu*F - AtMVMx(Omega,u,dim) - W);
    
    %% stopping criterion
     % eta_d
     ed0 = Z - mu*F - AtMVMx(Omega,u,dim) - W;
     ed = norm(ed0(:))/(1+norm(mu*F(:)));
     % eta_u
     eu0 = m*u - y + AMVMx(Omega, X);
     eu = norm(eu0(:))/(1 + norm(y));
     % eta_w
     ew0 = X - sign(X - W).*min(abs(X - W),c);
     ew = norm(ew0(:))/(1 + norm(X(:)) + norm(W(:)));
     % eta_z
     ez0 = Z - projection(X + Z,mu);
     ez = norm(ez0(:))/(1 + norm(X(:)) + norm(Z(:)));
     
     er = max([ed eu ew ez]);
     
     if er <= tol
         break;
     end
 
     if norm(F(:)) > 0
     RD = norm(ed(:));
     RP = max([eu ew ez]);
     XPD = RP/RD;
     if max(XPD,1/XPD) > Theta
         beta = xi*beta;
     else
         beta = beta/xi;
     end
     
     end
    
    %%
    X0 = X;
    Z0 = Z;
    W0 = W;
    
    
end

end
