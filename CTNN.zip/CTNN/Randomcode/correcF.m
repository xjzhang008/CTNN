% Computing the correction term


function  F = correcF(X,u,e)
[U D V] = svd(X);
[m n] = size(D);
t = min(m,n);
a = diag(D);
b = max(a);
c = a./b;
fai = @(c,u,e) sign(c).*(1+e^u).*(abs(c).^u)./(abs(c).^u+e^u);
fi = fai(c,u,e);
% for i=1:t
%     D(i,i)=fi(i);
% end

D = diag(fi);

if m <= n
    
    F = U*D*V(:,1:t)';
else
    
    F = U(:,1:t)*D*V';
end


end