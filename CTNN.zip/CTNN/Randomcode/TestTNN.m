%% sGS-ADMM for TNN model

addpath('tensor_toolbox');

randn('seed',2013); randn('seed',2013);
n1 = 50;
n2 = 50; 
n3 = 50;
% r = round(0.1*n1); % tubal rank
r = 3; % tubal rank
XT = tprod(randn(n1,r,n3),randn(r,n2,n3)); % size: n1*n2*n3, true tensor 
% XT = XT;
dim = [n1, n2, n3];

%% initial parameters


%%  Set  Omega
sr = 0.3;     % sampling ratio
p = round(sr*prod(n1*n2*n3));
Omega = randsample(prod(n1*n2*n3),p);


%% observed data
sigma = 0.01;
y =  AMVMx(Omega,XT+sigma*randn(n1,n2,n3));
mm = length(y);
m = 1;
% mu = 0.05;

rho1 = [50];

for jj = 1:length(rho1)

    fprintf('rho1 = %0.8e\n',rho1(jj));
    
    beta = 1000;

Theta = 50;
xi = 1.6;
gamma = 1.618;
MaxIte = 500;
tol = 1e-4;
c = max(XT(:));
MaxCo = 2;  % corrected number +1
    
%% Initial point
F = zeros(n1,n2,n3);
X0 = zeros(n1,n2,n3);
W0 = X0;
Z0 = X0;

barn = min(n1,n2);
mu = 0.05; %% 50*sigma*(norm(y)/sqrt(mm))*sqrt(2*log(n1*n3+n2*n3)/(mm*barn*n3));

opts.Theta = Theta;
opts.xi = xi;
opts.gamma = gamma;
opts.tol = tol;   
opts.m = m;  
opts.c = c;  
opts.beta = beta;  
opts.MaxIte = MaxIte;     
opts.X0 = X0;                
opts.W0 = W0;                
opts.Z0 = Z0;                
opts.mu = mu;               
opts.Omega = Omega;          
opts.dim = dim;       

%%  parameters in F
    tau = 2;                        % u in F
    e = 0.3;                     % e in F

    
 for ii = 1:MaxCo   

     if ii > 1  % F=0
%          rho1 = 5000;
         mu = rho1(jj)*sigma*((norm(y)/sqrt(mm)))*sqrt(2*log(n1*n3+n2*n3)/(mm*barn*n3));
         beta = 10;
         opts.mu = mu;   
         opts.beta = beta;  
     end
     
%% sGS-ADMM
         [X Z W trank] = TNN(F,y,Omega,dim,opts);

         F = CorrectedF(X,tau,e);
    
         opts.X0 = X;                
         opts.W0 = W;                
         opts.Z0 = Z;   
         opts.mu = mu;   
%% print the relative error
    Error = norm(X(:)-XT(:))/norm(XT(:));
    fprintf('Relative error = %0.8e\n',Error);
 
 end
 
end
 %% corrected model   


