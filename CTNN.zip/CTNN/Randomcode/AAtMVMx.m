%% compute   y = A*A'*b

function  y = AAtMVMx(A,b,dim)
       % y = A*A'*b
       Atx =  AtMVMx(A,b,dim);
       y = AMVMx(A,Atx);
end
       