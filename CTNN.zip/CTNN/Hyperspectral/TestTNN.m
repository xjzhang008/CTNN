%% sGS-ADMM for TNN model
clear all;
addpath('tensor_toolbox');


I = load('HP.mat');
I = I.HP;
I = double(I)./max(I(:));

XT = I;
[n1 n2 n3] = size(I);
dim  = size(I);

%%  Set  Omega
sr = [ 0.1];     % sampling ratio

for jj = 1:length(sr)

%% initial parameters
Theta = 50;
xi = 1.6;

beta = 5000;

gamma = 1.618;
MaxIte = 300;
tol = 1e-4;
c = max(XT(:));
MaxCo = 4;  % corrected number +1





p = round(sr(jj)*prod(n1*n2*n3));
Omega = randsample(prod(n1*n2*n3),p);


%% observed data
sigma = 0.001;
y =  AMVMx(Omega,XT+sigma*randn(n1,n2,n3));
mm = length(y);
m = 1;
% mu = 0.05;

%% Initial point
F = zeros(n1,n2,n3);
X0 = zeros(n1,n2,n3);
W0 = X0;
Z0 = X0;
barn = min(n1,n2);
mu = 0.005;

opts.Theta = Theta;
opts.xi = xi;
opts.gamma = gamma;
opts.tol = tol;   
opts.m = m;  
opts.c = c;  
opts.beta = beta;  
opts.MaxIte = MaxIte;     
opts.X0 = X0;                
opts.W0 = W0;                
opts.Z0 = Z0;                
opts.mu = mu;               
opts.Omega = Omega;          
opts.dim = dim;    

fprintf('SR = %0.8e\n',sr(jj));

%%  parameters in F
%     tau = 2;                        % u in F  %% HP 2
%     e = 1;                     % e in F  %% HP 1
    tau = 2;                        % u in F
    e = 0.3;                     % e in F

 for ii = 1:MaxCo   

     if ii > 1  % F=0
         mu = 50000*sigma*(norm(y)/sqrt(mm))*sqrt(2*log(n1*n3+n2*n3)/(mm*barn*n3));
         beta = 10;
         opts.mu = mu;   
         opts.beta = beta;  
     end
     
%% sGS-ADMM
         [X Z W trank] = TNN(F,y,Omega,dim,opts);

         F = CorrectedF(X,tau,e);
    
         opts.X0 = X;                
         opts.W0 = W;                
         opts.Z0 = Z;   
         opts.mu = mu;  
         
         if ii == 1
             Y = X; 
         end
         
%% print the relative error
    Error = norm(X(:)-XT(:))/norm(XT(:));
    PSNR = psnr(X(:),XT(:));
    fprintf('Relative error = %0.8e, PSNR = %4.2fdB\n',Error,PSNR);
    
    
 
 end
 
end
 %% corrected model   


